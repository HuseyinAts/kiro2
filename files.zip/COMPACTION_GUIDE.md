# Compaction Guide

## When to Compact

### Token Usage Zones
- **0-70%**: Normal operation
- **70-90%**: ⚠️ Start preparing for compaction
- **90-95%**: 🔴 Proactive compact NOW
- **95%+**: 🚨 Emergency - immediate handoff

## Proactive Compaction (Recommended)

At **70% token usage**:
```
Create HANDOFF.md with:
1. Session summary
2. Key decisions
3. Current state
4. Next steps

Then: /clear and load HANDOFF.md
```

## Emergency Recovery

If near 100%:
1. Immediately create minimal HANDOFF.md
2. Use /clear
3. New session: Read HANDOFF.md first
4. Continue work

## Edit Prompt Technique

For large edits, use edit prompts:
```
Edit /path/to/file:
- Change line X from A to B
- Add lines after Y: [content]
- Remove lines Z-W
```

**Savings**: 67% fewer tokens vs traditional iteration

## Best Practices
- Compact proactively, not reactively
- Use edit prompts for modifications
- Keep CLAUDE.md under 2000 tokens
- Disable unused MCP servers
- Use .claudeignore for large files
