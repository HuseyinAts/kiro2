# KIRO2 - Turkish YKS Exam Prep Platform

## Tech Stack
- **Backend**: FastAPI (Python 3.11+), PostgreSQL (port 5434), Redis
- **Frontend**: React 18 + TypeScript
- **AI/NLP**: Qwen3-8B (Turkish fine-tuned), BERTurk, Zemberek
- **Algorithms**: IRT, FSRS, ZPD

## Project Structure
```
kiro2/
├── backend/          # 588 files, 50+ routers
├── frontend/         # 780+ files, 40+ components
├── d-dataset/        # C:\Users\husey\d-dataset (OCR data)
└── tests/
```

## Critical Commands
```bash
# Backend
cd backend && pytest -v --cov=app
uvicorn app.main:app --reload --port 8000

# Frontend
cd frontend && npm test -- --coverage
npm run dev

# All checks
npm run check-all  # lint + format + typecheck + test
```

## Agent Routing Rules

### Claude Code (this agent) for:
- Turkish NLP (sentiment, question gen, Qwen3-8B)
- Security (auth, vulnerabilities, audits)
- Complex refactoring (multi-file)
- Database schema/migrations
- Deep debugging
- Performance optimization

### Codex CLI for:
- React components (new creation)
- FastAPI endpoints (boilerplate)
- Unit test generation
- Documentation (OpenAPI, README)
- Docker/CI-CD config
- CSS/Tailwind

## Routing Logic
```
IF [türkçe|turkish|nlp|qwen|sentiment] → Claude
IF [security|auth|vulnerability] → Claude
IF [refactor|architecture] → Claude
IF [react|component|ui|css] → Codex
IF [test|jest|pytest] AND simple → Codex
IF [create|new] AND simple → Codex
ELSE → Codex (default: faster, cheaper)
```

## Code Standards
- **Python**: Type hints required, async for I/O, Pydantic validation
- **TypeScript**: Functional components, hooks, strict types
- **Turkish**: UTF-8 encoding, Zemberek for morphology

## Key Files
- `backend/app/main.py` - FastAPI entry (810 lines)
- `backend/app/core/config.py` - Configuration
- `frontend/src/store/authStore.ts` - Auth state (320 lines, prod-ready)
- `frontend/src/services/examService.ts` - Exam API (900 lines)

## Current Status
- Platform: 95% complete
- Emergency: emergency_content.sql (50Q not loaded)
- Content Crisis: 2,436/75,745 match rate (0.11%, target: 66%)
- Database: PostgreSQL port 5434

## Environment
```bash
DATABASE_URL=postgresql://user:pass@localhost:5434/kiro2
REDIS_URL=redis://localhost:6379/0
JWT_SECRET=your-secret-key
QWEN_MODEL_PATH=/models/qwen3-8b-turkish
```

## Git Convention
```
feat: New feature
fix: Bug fix
refactor: Code refactoring
docs: Documentation
test: Tests
```
